import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import mysql from 'mysql2/promise';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';

const router = express.Router();

// Database connection pool
let pool;

export function initializeAuthRoutes(dbPool) {
  pool = dbPool;
  return router;
}

// ============================================
// MIDDLEWARE
// ============================================

// Rate limiting for login attempts
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per windowMs
  message: 'Too many login attempts, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiting for registration
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // 3 attempts per hour
  message: 'Too many registration attempts from this IP',
  standardHeaders: true,
  legacyHeaders: false,
});

// Verify JWT token middleware
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Hash password securely
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

// Compare passwords
async function comparePasswords(password, hash) {
  return bcrypt.compare(password, hash);
}

// Generate JWT tokens
function generateTokens(user) {
  const accessToken = jwt.sign(
    {
      id: user.id,
      uuid: user.uuid,
      username: user.username,
      email: user.email,
      user_type: user.user_type,
    },
    process.env.JWT_SECRET || 'your-secret-key',
    { expiresIn: '24h' }
  );

  const refreshToken = jwt.sign(
    {
      id: user.id,
      uuid: user.uuid,
    },
    process.env.REFRESH_TOKEN_SECRET || 'your-refresh-secret',
    { expiresIn: '7d' }
  );

  return { accessToken, refreshToken };
}

// Hash token for storage
function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// Log login attempts
async function logLoginAttempt(username, ipAddress, userAgent, success, userId = null) {
  try {
    const conn = await pool.getConnection();
    await conn.execute(
      'INSERT INTO login_attempts (user_id, username, ip_address, user_agent, success) VALUES (?, ?, ?, ?, ?)',
      [userId, username, ipAddress, userAgent, success]
    );
    conn.release();
  } catch (error) {
    console.error('Error logging login attempt:', error);
  }
}

// ============================================
// AUTH ROUTES
// ============================================

// REGISTER
router.post('/register', registerLimiter, async (req, res) => {
  try {
    const { username, email, password, full_name, phone, national_id, user_type } = req.body;

    // Validate input
    if (!username || !password || !full_name) {
      return res.status(400).json({
        error: 'Username, password, and full name are required',
      });
    }

    // Validate password strength
    if (password.length < 8) {
      return res.status(400).json({
        error: 'Password must be at least 8 characters long',
      });
    }

    const conn = await pool.getConnection();

    try {
      // Check if user exists
      const [existingUser] = await conn.execute(
        'SELECT id FROM users WHERE username = ? OR email = ?',
        [username, email]
      );

      if (existingUser.length > 0) {
        return res.status(409).json({
          error: 'Username or email already exists',
        });
      }

      // Hash password
      const password_hash = await hashPassword(password);
      const uuid = uuidv4();

      // Create user
      const [userResult] = await conn.execute(
        `INSERT INTO users (uuid, username, email, password_hash, full_name, phone, national_id, user_type)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [uuid, username, email || null, password_hash, full_name, phone || null, national_id || null, user_type || 'school']
      );

      const userId = userResult.insertId;

      // Create user profile
      await conn.execute(
        `INSERT INTO user_profiles (user_id, school_name) VALUES (?, ?)`,
        [userId, full_name]
      );

      // Log audit
      await conn.execute(
        `INSERT INTO audit_logs (user_id, action, entity_type, entity_id)
         VALUES (?, ?, ?, ?)`,
        [userId, 'USER_REGISTERED', 'users', userId]
      );

      conn.release();

      // Generate tokens
      const user = {
        id: userId,
        uuid,
        username,
        email,
        user_type: user_type || 'school',
      };

      const tokens = generateTokens(user);

      // Store refresh token
      const conn2 = await pool.getConnection();
      const tokenHash = hashToken(tokens.refreshToken);
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

      await conn2.execute(
        `INSERT INTO auth_tokens (user_id, token_hash, token_type, expires_at)
         VALUES (?, ?, ?, ?)`,
        [userId, tokenHash, 'refresh', expiresAt]
      );
      conn2.release();

      res.status(201).json({
        success: true,
        user: {
          id: userId,
          uuid,
          username,
          email,
          full_name,
          user_type: user_type || 'school',
        },
        ...tokens,
      });
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// LOGIN
router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { username, password } = req.body;
    const ipAddress = req.ip || req.connection.remoteAddress;
    const userAgent = req.get('user-agent');

    // Validate input
    if (!username || !password) {
      await logLoginAttempt(username, ipAddress, userAgent, false);
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const conn = await pool.getConnection();

    try {
      // Find user
      const [users] = await conn.execute(
        `SELECT id, uuid, username, email, password_hash, full_name, user_type, status
         FROM users WHERE username = ?`,
        [username]
      );

      if (users.length === 0) {
        await logLoginAttempt(username, ipAddress, userAgent, false);
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const user = users[0];

      // Check status
      if (user.status !== 'active') {
        await logLoginAttempt(username, ipAddress, userAgent, false, user.id);
        return res.status(403).json({
          error: `Account is ${user.status}. Please contact support.`,
        });
      }

      // Verify password
      const isValidPassword = await comparePasswords(password, user.password_hash);

      if (!isValidPassword) {
        await logLoginAttempt(username, ipAddress, userAgent, false, user.id);
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      // Update last login
      await conn.execute('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);

      // Log successful attempt
      await logLoginAttempt(username, ipAddress, userAgent, true, user.id);

      conn.release();

      // Generate tokens
      const tokens = generateTokens(user);

      // Store refresh token
      const conn2 = await pool.getConnection();
      const tokenHash = hashToken(tokens.refreshToken);
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

      await conn2.execute(
        `INSERT INTO auth_tokens (user_id, token_hash, token_type, expires_at)
         VALUES (?, ?, ?, ?)`,
        [user.id, tokenHash, 'refresh', expiresAt]
      );

      // Store session
      const sessionToken = crypto.randomBytes(32).toString('hex');
      const sessionHash = hashToken(sessionToken);
      const sessionExpires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

      await conn2.execute(
        `INSERT INTO user_sessions (user_id, session_token_hash, ip_address, user_agent, expires_at)
         VALUES (?, ?, ?, ?, ?)`,
        [user.id, sessionHash, ipAddress, userAgent, sessionExpires]
      );

      conn2.release();

      res.json({
        success: true,
        user: {
          id: user.id,
          uuid: user.uuid,
          username: user.username,
          email: user.email,
          full_name: user.full_name,
          user_type: user.user_type,
        },
        ...tokens,
      });
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// REFRESH TOKEN
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ error: 'Refresh token is required' });
    }

    try {
      const decoded = jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET || 'your-refresh-secret'
      );

      const conn = await pool.getConnection();

      // Verify token is in database
      const tokenHash = hashToken(refreshToken);
      const [tokenRecords] = await conn.execute(
        `SELECT id FROM auth_tokens WHERE user_id = ? AND token_hash = ? AND token_type = 'refresh' AND revoked = FALSE`,
        [decoded.id, tokenHash]
      );

      if (tokenRecords.length === 0) {
        conn.release();
        return res.status(401).json({ error: 'Invalid refresh token' });
      }

      // Get user
      const [users] = await conn.execute(
        `SELECT id, uuid, username, email, user_type FROM users WHERE id = ?`,
        [decoded.id]
      );

      conn.release();

      if (users.length === 0) {
        return res.status(401).json({ error: 'User not found' });
      }

      const user = users[0];
      const newTokens = generateTokens(user);

      res.json(newTokens);
    } catch (error) {
      return res.status(401).json({ error: 'Invalid refresh token' });
    }
  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// LOGOUT
router.post('/logout', verifyToken, async (req, res) => {
  try {
    const { refreshToken } = req.body;
    const userId = req.user.id;

    const conn = await pool.getConnection();

    try {
      // Revoke refresh token
      if (refreshToken) {
        const tokenHash = hashToken(refreshToken);
        await conn.execute(
          `UPDATE auth_tokens SET revoked = TRUE, revoked_at = NOW()
           WHERE user_id = ? AND token_hash = ?`,
          [userId, tokenHash]
        );
      }

      // Log audit
      await conn.execute(
        `INSERT INTO audit_logs (user_id, action, entity_type)
         VALUES (?, ?, ?)`,
        [userId, 'USER_LOGGED_OUT', 'users']
      );

      conn.release();

      res.json({ success: true, message: 'Logged out successfully' });
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export { verifyToken };
